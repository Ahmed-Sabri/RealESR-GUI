from flask import Flask, request, send_file
import torch
from PIL import Image
from RealESRGAN import RealESRGAN
import io
import os
from huggingface_hub import hf_hub_download

app = Flask(__name__)

# Create static folder if it doesn't exist
os.makedirs('static', exist_ok=True)

# Initialize the model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = RealESRGAN(device, scale=4)
model.load_weights('weights/RealESRGAN_x4.pth', download=True)

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/upscale', methods=['POST'])
def upscale():
    if 'image' not in request.files:
        return 'No image uploaded', 400

    # Get the uploaded image
    file = request.files['image']
    img = Image.open(file.stream).convert('RGB')

    # Process the image with Real-ESRGAN
    sr_image = model.predict(img)

    # Save the result to a bytes buffer
    img_byte_arr = io.BytesIO()
    sr_image.save(img_byte_arr, format='PNG')
    img_byte_arr.seek(0)

    return send_file(img_byte_arr, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)